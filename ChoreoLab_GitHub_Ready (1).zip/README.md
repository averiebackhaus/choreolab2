
# ChoreoLab

ChoreoLab is a web-based choreography visualization tool. Upload pose data and audio to animate dancers, edit formations, and sync everything to music on an interactive timeline.

## Features
- Upload JSON pose data and audio files
- Visualize multiple dancers
- Drag-and-drop dancers on a grid
- Save and label formations
- Animated transitions and timeline syncing

## Getting Started
```bash
npm install
npm start
```
