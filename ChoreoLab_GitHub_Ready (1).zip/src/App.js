
import React from "react";

function App() {
  return <div>Hello from ChoreoLab!</div>;
}

export default App;
